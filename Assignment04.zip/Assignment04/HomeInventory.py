# TitleL Home Inventory and data file store script.
# Dev: MSteinauer
# Date: August 3, 2022
# ChangeLog: (Who, When, What)
#   Msteinauer,8/03/2022,Created Script







#Variables listed:

objFile = None
strItem = ''
strValue = ''
option = ''
lstInventory = []
lstTable = []

# Step 1
# Display a menu of choices to the user
# ("Add Data to List", "Display Current Data", "Exit and Save to File")

while (True):
    print("""
    1) Add Items to your Inventory List
    2) Display Current Inventory
    3) Exit and Save to a File
    """)

# Step 2
# Add a new item to the List(Table) each time the user makes that choice

    option = str(input("Which Option would you like to Perform? [1 to 3]: "))
    if option == '1':
        print("Type in the name and value of a house hold items")
        strItem = input('Enter the item: ')
        strValue = input('Enter estimated value: ')
        lstInventory = [strItem, strValue]
        lstTable += [lstInventory]

 # Step 3
# Display the data in the List(Table) each time the user makes that choice

    elif option == '2':
        print('Your current Inventory is: ')
        for row in lstTable:
            print(' ', row[0], ',', row[1], sep='')

    # Step 4
    # Exit the program and save the data to a text file when the user makes that choice

    elif option == '3':
        print(" Would you like to save your Data?")
        strOption = str(input(" Enter 'y' or 'n': "))
        if (strOption.lower() == 'y'):
            objFile = open("HomeInventory.txt", "w")
            for row in lstTable:
                objFile.write(str(row[0]) +"," + str(row[1]) + "\n")
            objFile.close()
        else:
            print(" Changes were not saved!")
        break

# This is what I tried to do, it would only write one item to the file... ???
        # for row in lstTable:
        #     objFile = open('homeinventory.txt', 'w')
        #     objFile.write(str(row[0]) + "," + str(row[1]) + "\n")
        #     objFile.close()
        #     print("Data Saved to File!")
        # else:
        #  break

